module.exports = {
    'secret': 'supersecret',
};
