module.exports = {
    DB: 'mongodb://max:170388max@ds127949.mlab.com:27949/apptodo'
};